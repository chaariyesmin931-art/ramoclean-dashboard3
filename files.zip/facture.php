<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ramo Clean — Factures</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
  $conn = new mysqli("localhost","root","","ramoclean");
  if($conn->connect_error) die("Connection failed: ".$conn->connect_error);
?>
<?php require("insights.php"); ?>

<nav>
  <div class="nav-logo-area">
    <img src="logonobg.png" alt="Ramo Clean">
    <span class="nav-sub">100% Naturel</span>
  </div>
  <p class="nav-section-label">Menu</p>
  <ul>
    <li><a href="main.php">⬡ Dashboard</a></li>
    <li><a href="facture.php" class="active">⬡ Facture</a></li>
    <li><a href="produit.php">⬡ Produit</a></li>
    <li><a href="matiere.php">⬡ Matiere</a></li>
  </ul>
  <p class="nav-section-label" style="margin-top:10px;">Personnes</p>
  <ul>
    <li><a href="client.php">⬡ Client</a></li>
    <li><a href="fournisseur.php">⬡ Fournisseur</a></li>
    <li><a href="employe.php">⬡ Employe</a></li>
  </ul>
</nav>

<div class="dashboard">

  <div class="page-header">
    <h2>🧾 Factures</h2>
    <a href="ajoutfacture.php" class="btn-primary">+ Nouvelle Facture</a>
  </div>

  <div class="stat-row">
    <div class="stat-box">
      <h3>Total Factures</h3>
      <p><?php echo $totalFactures; ?></p>
    </div>
    <div class="stat-box">
      <h3>Ce mois</h3>
      <p><?php echo $facturesMonth; ?></p>
    </div>
    <div class="stat-box">
      <h3>Différence</h3>
      <p style="color:<?php echo $difference >= 0 ? '#2e5c1e' : '#a32d2d'; ?>">
        <?php echo ($difference >= 0 ? '+' : '').$difference; ?>
      </p>
    </div>
    <div class="stat-box">
      <h3>Exporter</h3>
      <a href="export_excel.php" class="btn-spark" style="margin-top:6px;">📥 Download Excel</a>
    </div>
  </div>

  <div class="search-wrap">
    <form method="GET" class="search-form">
      <input type="text" name="searchf" placeholder="Rechercher facture ou client..."
        value="<?php echo htmlspecialchars(isset($_GET['searchf']) ? $_GET['searchf'] : ''); ?>">
      <select name="month">
        <option value="">Tous les mois</option>
        <?php for($m=1;$m<=12;$m++){
          $sel=(isset($_GET['month'])&&$_GET['month']==$m)?"selected":"";
          echo "<option value='$m' $sel>".date("F",mktime(0,0,0,$m,1))."</option>";
        } ?>
      </select>
      <button type="submit">Rechercher</button>
    </form>
    <a href="facture.php" class="reset-btn">Réinitialiser</a>
  </div>

  <div class="data-grid">
    <?php if($resultFactures->num_rows > 0): while($row=$resultFactures->fetch_assoc()): ?>
    <div class="data-card">
      <h2>Facture #<?php echo str_pad($row['NumFact'],4,"0",STR_PAD_LEFT); ?></h2>
      <h4>Client: <?php echo htmlspecialchars($row['NomEntreprise']); ?></h4>
      <p>Date: <?php echo $row['datefact']; ?></p>
      <?php if($row['payment']==1): ?>
        <span class="pill pill-green">✓ Payée</span>
      <?php else: ?>
        <span class="pill pill-amber">⏳ Non payée</span>
      <?php endif; ?>
      <br>
      <a href="details_facture.php?id=<?php echo $row['NumFact']; ?>" class="details-btn">Détails</a>
    </div>
    <?php endwhile; else: ?>
    <div class="empty-state">Aucune facture trouvée.</div>
    <?php endif; ?>
  </div>

</div>
<?php $conn->close(); ?>
</body>
</html>
